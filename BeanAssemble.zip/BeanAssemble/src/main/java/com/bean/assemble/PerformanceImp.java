package com.bean.assemble;

/**
 * Created by zhuxinquan on 17-4-19.
 */
public class PerformanceImp implements PerfromanceInterface {
    public void perform(){
        System.out.println("perform");
    }
}
