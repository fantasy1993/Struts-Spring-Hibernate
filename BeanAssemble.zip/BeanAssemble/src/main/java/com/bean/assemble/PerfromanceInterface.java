package com.bean.assemble;

/**
 * Created by zhuxinquan on 17-4-19.
 */
public interface PerfromanceInterface {
    public void perform();
}
